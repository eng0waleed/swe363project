<!-- Map start  -->

<div  id="Contact" class="container-fluid page-wrapper">
    <div class="row">
        <div class="col-lg-5 col-sm-12 p-5">
            <div class="contact-info text-center text-light">
                <p>
                    phone:+966-13-860-0000
                </p>
                <div class="time inline-elements p-5">

                            <span>
                                <img src="Images/clock.svg " >
                            </span>
                    <div class="info">
                        <p>sun-thur 11:00 - 23:00</p>
                        <p>fri-sat 12:00-23</p>
                    </div>
                </div>

                <div class="time location inline-elements p-5">

                        <span>
                            <img src="Images/placeholder.svg " >
                        </span>
                    <div class="info">
                        <p>123 KFUPM students Mall</p>
                        <p>Dhahran 34464</p>
                    </div>
                </div>

                <div class="inline-elements socialMedia">
                    <p><a href="https://facebook.com/"> Facebook</a></p>
                    <p><a href="https://twitter.com//"> Twitter</a></p>
                    <p><a href="https://instagram.com/"> Instagram</a></p>
                </div>
            </div>

        </div>
        <div class="col-lg-7 map col-sm-12">

            &nbsp;  <img class="img-fluid float-end" src="Images/map.png">

        </div>
    </div>
</div>

<!-- Map end  -->

<!-- footer start -->
<footer class="footer">
    <div class="container p-3 mt-4">
        <div class="row">
            <div class="col-lg-4 col-md-12 col-sm-12">
                <img src="./Images/logo-red.svg" alt="" srcset="">
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Neque ullam deserunt laborum, laboriosam veritatis quibusdam blanditiis dolor exercitationem velit commodi quae assumenda incidunt voluptas. Corporis ex nulla repellendus ullam nihil!</p>
            </div>
            <div class="col-lg-4 col-md-6 col-sm-12">
                <h2 class="Titles">
                    Useful Links
                </h2>
                <ul class=" p-5 footer-links">
                    <li><a href="# ">About</a></li>
                    <li><a href="#Menu ">Menu</a></li>
                    <li><a href="#Testimonials ">Testimonials</a></li>
                    <li><a href="#Contact ">Contact Us</a></li>
                </ul>
            </div>
            <div class="col-lg-4 col-md-6 col-sm-12">

                <div class="col-sm-6 col-md-6 col-lg-6"><h3 class="Titles col-lg-12">INSTAGRAMFEEDS</h3></div>

                <div>
                    <div class="">
                        <img  class="pics col-lg-4 col-md-4 col-sm-4" src="Images/meal1.png ">
                        <img  class="pics col-lg-4 col-md-4 col-sm-4" src="Images/meal2.png ">
                        <img  class="pics col-lg-4 col-md-4 col-sm-4" src="Images/meal3.png ">
                    </div>
                    <div class="">
                        <img  class="pics col-lg-4 col-md-4 col-sm-4" src="Images/meal1.png ">
                        <img  class="pics col-lg-4 col-md-4 col-sm-4" src="Images/meal2.png ">
                        <img  class="pics col-lg-4 col-md-4 col-sm-4" src="Images/meal3.png ">
                    </div>

                </div>


            </div>
        </div>
    </div>
</footer>


<script type="text/javascript" src="https://code.jquery.com/jquery-1.12.0.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.bundle.min.js"></script>
<!-- <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.min.js"></script> -->

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js" integrity="sha384-JEW9xMcG8R+pH31jmWH6WWP0WintQrMb4s7ZOdauHnUtxwoG2vI5DkLtS3qm9Ekf" crossorigin="anonymous"></script>

</body>
</html>
