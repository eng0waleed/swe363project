<?php
require_once '../php/meal_db.php';
$connection = new Meal_db();
$meals = $connection->getAllMeals();
var_dump($meals);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Hot Burger</title>

    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@200;300;400&family=Roboto&display=swap" rel="stylesheet">
    <script src="app.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.theme.min.css">

    <script src="app.js" defer></script>

    <link rel="stylesheet" href="css/style.css">

</head>


<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top py-1">
    <div class="container">
        <a href="index.php"> <img style="width: 6rem; height: 5rem;" src="Images/logo-White.svg"/></a>
        <button class="navbar-toggler collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
        <div class="collapse navbar-collapse  mt-4 mt-lg-0" id="navbarSupportedContent">

            <ul class="navbar-nav mx-auto pt-2 pt-lg-0 font-base">
                <li class="nav-item px-2 blacklistD" data-anchor="data-anchor"><a class="nav-link active" aria-current="page" href="index.php">Home</a></li>
                <li class="nav-item px-2 blacklistD" data-anchor="data-anchor"><a class="nav-link" href="#Menu">Menu</a></li>
                <li class="nav-item px-2 blacklistD" data-anchor="data-anchor"><a class="nav-link" href="#Gallery">Gallery </a></li>
                <li class="nav-item  blacklistD" data-anchor="data-anchor"><a class="nav-link" href="#Testimonials">Testimonials </a></li>
                <li class="nav-item px-2 blacklistD" data-anchor="data-anchor"><a class="nav-link" href="#Contact">Contact Us </a></li>
                <li class="nav-item px-2 redlist" data-anchor="data-anchor"><a class="nav-link" href="#">Search </a></li>
                <li class="nav-item px-2 redlist" data-anchor="data-anchor"><a class="nav-link" href="#">Profile </a></li>
                <li class="nav-item px-2 redlist" data-anchor="data-anchor"><a class="nav-link" href="#">Cart </a></li>
                <li class="nav-item px-2 redlist" data-anchor="data-anchor" style="cursor: pointer"   onclick="cartView()">
                    <span id="theNumber">0</span>
                </li>
            </ul>

        </div>
    </div>
</nav>

<div class="modal fade" id="cartModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-md modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header border-bottom-0">
                <h5 class="modal-title" id="exampleModalLabel">
                    Cart Content
                </h5>
                <button type="button" id="closemodal" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <table class="table table-image">
                    <thead>
                    <tr>

                        <th scope="col">Item</th>
                        <th scope="col">Price</th>
                    </tr>
                    </thead>
                    <tbody id="cartBody">

                    </tbody>
                    <tr><td>Total</td><td id="totalCost">0</td></tr>
                </table>
            </div>
            <div class="modal-footer border-top-0 d-flex justify-content-right">
                <button type="button" class="redbtn" id="closemodal" data-dismiss="modal">Close</button>
                <button type="submit" class="yellowbtn" onclick="emptyCart()">Order Now</button>
            </div>
        </div>
    </div>
</div>

<?php
require 'php/php/meal.php';

?>
