<?php
require_once 'include/inc.header.php';
$meal = new Meal;
?>
<!--



Comment:

This submission includes everything working properly with the exception of:
3a, 3b,3c,3d they all commented or half implemented we had a problem integrating them










-->
<div class="container-fluid headerESection">
    <div class="row align-items-center min-vh-md-75">
        <div class="col col-lg-6 col-sm-12 position-relative">
            <h1 class="text-center" id="partyA">Party Time</h1>
            <div id="polygonA">
                <p id="polygonA-text">Buy any 2 burgers and get 1.5L Pepsi Free</p>
            </div>
            <!-- End -->
            <form action="php/order.php" method="POST">
                <?php
                $mealsIDs = array('2','4','6');
                foreach($mealsIDs as $value)
                {
                    echo '<input type="hidden" name="mealsIDs[]" value="'. $value. '">';
                }
                ?>
                <!--<input type="hidden" name="mealsIDs" value="<?php //print_r($mealsIDs);?>"> -->
                <input type="hidden" name="cartTotal" value="123">
                <button type="submit" class="btnsFont btn2" style="border:0px; text-align: center; margin-top: 10rem ; padding-left: 1.5rem; padding-top: 0.3rem;" onclick="emptyCart()">Order Now</button>
            </form>
        </div>
        <!-- <div class="col">
          2 of 2
        </div> -->
    </div>

</div>


<?php if(isset($_COOKIE["recent-bought"])) {?>


    <div  id="Gallery" class="container fourthSection py-3" id="header1">
    <div class="p-3"></div>
    <h2 class="text-center Titles p3">
        Your Recent Bought Product
    </h2>

    <div class="row">

        <?php

            $meal1 = array();

            foreach (json_decode($_COOKIE["recent-bought"]) as $cookiesMeal){
                array_push($meal1, $meal->getMealById($cookiesMeal-1));
            }

        ?>

        <?php foreach($meal1 as $mealtemp){ ?>

            <div class="col-lg-3 col-md-4 col-sm-12">
                <form  action="php/cart.php" method="GET">
                    <div class="itemA">
                        <a href=<?php echo "detail.php?id=".$mealtemp["id"] ?> style="text-decoration: none;">
                        <img src=<?php echo '"'. $mealtemp["image"].'"'; ?> alt="" alt="">

                        <p>&#11088; <?php echo $mealtemp["rating"];?> rating</p>
                        <h3><?php echo $mealtemp["title"];?></h3>
                        <p>Some Description</p>
                        </a>
                        <input type="hidden" name="id" value=<?php echo $mealtemp["id"] ?>>


                        <button type="submit" style="cursor: pointer; border:0px; text-align: center; padding-left: 1.7rem; padding-top: 0.2rem;" class="btnsFont btn2">Buy Again</button>

                        <p CLASS="besidebtn"><?php echo $mealtemp["price"];?> SAR</p>

                    </div>

                </form>

            </div>

        <?php } ?>

    </div>

    </div>

<?php } ?>

<div  id="Menu" class="container-fluid p-5 menu">
    <h2 class=" Titles">
        Want To Eat
    </h2>
    <p class="text-center">
        Try our most delicious food and usually take minutes to deliver
    </p>

        <ul id="menuA" class="nav justify-content-center pb-5">
            <li><a href="Images/pizza.svg">pizza</a></li>
            <li><a href="#">fast food</a></li>
            <li><a href="Images/cubcake.svg">cupcake</a></li>
            <li><a href="Images/sandwich.svg">sandwitch</a></li>
            <li><a href="#">spaghetti</a></li>
            <li><a href="Images/burger.svg">burger</a></li>
        </ul>


</div>
<!-- The End of the menu section -->

<!-- The begining of the third section of the page -->
<div class="container-fluid thirdSection" id="header1">
    <div class="row align-items-center min-vh-md-75">
        <div class="col-xs-12 col-lg-6  col-sm-12 ">
            <img src="Images/delivery.png" alt="delivery man" width="809">
        </div>
        <div class="col col-lg-6 col-sm-12">
            <div class="text-center">
                <div class="float-end" id="polygonB">
                    <h2 id="polygonB-text">We guarantee 30 minutes <br> delivery</h2>
                </div>

                <div id="polygonB_Desc">
                    <p>If you are having a meeting, working late at night and need an extra push</p>
                </div>
            </div>
        </div>
    </div>

</div>
<!-- The End of the third section -->


<!-- The beginning of the fourth section  -->
<div  id="Gallery" class="container fourthSection py-3" id="header1">
    <div class="p-3"></div>
    <h2 class="text-center Titles p3">
        Our Most Popular Recipes
    </h2>
    <p class="text-center">
        Try our most delicious food and usually take minutes to deliver
    </p>
    <div class="row">

        <?php foreach($meal->getAllMeals() as $meal){ ?>

        <div class="col-lg-3 col-md-4 col-sm-12">
                <form  action="php/cart.php" mehod="GET">
                    <div class="itemA">
                        <a href=<?php echo "detail.php?id=".$meal["id"] ?> style="text-decoration: none;">
                        <img src=<?php echo '"'. $meal["image"].'"'; ?> alt="" alt="">

                        <p>&#11088; <?php echo $meal["rating"];?> rating</p>
                        <h3><?php echo $meal["title"];?></h3>
                        <p>Some Description</p>
                        </a>
                        <input type="hidden" name="id" value=<?php echo $meal["id"] ?>>

                        <?php if(isset($_COOKIE["cart"])) {?>
                            <input type="hidden" name="back" value=<?php echo(json_encode($_COOKIE["cart"]))?>>
                        <?php } ?>



                        <button type="submit" style="cursor: pointer; border:0px; text-align: center; padding-left: 0.8rem; padding-top: 0.2rem;" class="btnsFont btn2"> add to the cart</button>

                        <p CLASS="besidebtn"><?php echo $meal["price"];?> SAR</p>

                    </div>

                </form>

        </div>

        <?php } ?>

    </div>



<!-- Start Slider  -->


<div  id="Testimonials" class="py-5" id="venue">
    <div class="container">
        <div class="row  animate-in-down">
            <h3 class="Titles">Client Testimonials</h3>
            <div class="p-0 col-md-6">
                <div class="carousel slide" data-ride="carousel" id="carousel1">
                    <div class="carousel-indicators">
                        <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
                        <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1" aria-label="Slide 2"></button>
                        <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2" aria-label="Slide 3"></button>
                    </div>
                    <div class="carousel-inner" role="listbox">
                        <div class="carousel-item"> <img class="d-block img-fluid w-100" src="Images/man-eating-burger.png" alt="first slide">

                        </div>
                        <div class="carousel-item active"> <img class="d-block img-fluid w-100" src="Images/man-eating-burger.png" data-holder-rendered="true" alt="">

                        </div>
                        <div class="carousel-item"> <img class="d-block img-fluid w-100" src="Images/man-eating-burger.png" data-holder-rendered="true" alt="">

                        </div>
                    </div> <a class="carousel-control-prev" href="#carousel1" role="button" data-slide="prev"> <span class="carousel-control-prev-icon" aria-hidden="true"></span> <span class="sr-only">Previous</span> </a> <a class="carousel-control-next" href="#carousel1" role="button" data-slide="next"> <span class="carousel-control-next-icon" aria-hidden="true"></span> <span class="sr-only">Next</span> </a>
                </div>
            </div>

            <div class="p-4 col-md-6 align-self-center text-color">

                <p class="my-4 testimonial-p">
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Neque ullam deserunt laborum, laboriosam veritatis quibusdam blanditiis dolor exercitationem velit commodi quae assumenda incidunt voluptas. Corporis ex nulla repellendus ullam nihil!</p>
            </div>


        </div>
    </div>
</div>
</div>
<!-- End slider -->

<?php require_once 'include/inc.footer.php'?>