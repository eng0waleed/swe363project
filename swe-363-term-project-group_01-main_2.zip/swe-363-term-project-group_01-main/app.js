
currentLength = 0;

document.addEventListener("DOMContentLoaded", function() {
    let button = document.getElementById("btn2");
    if (button != null) {
        button.addEventListener("click", function() {
            steponup();
        });
    }

    function steponup() {
        let input = document.getElementById("theNumber").innerHTML;
        input++;
        document.getElementById("theNumber").innerHTML = input;
    }

    const messageEle = document.querySelector("#reviewArea");
    const counterEle = document.getElementById("counter");

    /*messageEle.addEventListener("input", function(e) {
        const target = e.target;
        var warningMessage = document.querySelector("#warningMessage");

        const maxLength = target.getAttribute("maxlength");
        currentLength = target.value.length;

        if (currentLength > 0) warningMessage.style.display = "none";

        counterEle.innerHTML = `${currentLength}/${maxLength}`;
    });*/

    var form = document.querySelector("form");
    let name = document.getElementById("reviewerName");

    $('#closemodal').click(function() {
        $('#cartModal').modal('hide');
    });
    $('.redbtn').click(function() {
        $('#cartModal').modal('hide');
    });
});



function updateNCart(name, price) {

    let input = document.getElementById("theNumber").innerHTML;
    input++;
    document.getElementById("theNumber").innerHTML = input;
    var tableEnd = document.getElementById("cartBody");

    let tablerow = document.createElement("tr");
    let tableCol1 = document.createElement("td");
    let tableCol2 = document.createElement("td");
    tableCol1.append(name);
    tableCol2.append(price);
    tablerow.appendChild(tableCol1);
    tablerow.appendChild(tableCol2);
    /*let itemHtml = "<tr><td> + name + <td><td> + price + <td><tr>";
    tableEnd.appendChild(itemHtml);*/
    tableEnd.appendChild(tablerow);

    let Total = document.getElementById("totalCost").innerHTML;

    Total = parseFloat(Total) + parseFloat(price);

    document.getElementById("totalCost").innerHTML = Total;
}

function emptyCart() {
    let input = 0;
    document.getElementById("theNumber").innerHTML = input;
    var old_table = document.getElementById("cartBody");
    var new_table = document.createElement('tbody');
    old_table.replaceWith(new_table);
    document.getElementById("totalCost").innerHTML = "0";


}

function updateNCart() {
    let input = document.getElementById("theNumber").innerHTML;
    input++;
    document.getElementById("theNumber").innerHTML = input;
}

function emptyCart() {
    let input = 0;
    document.getElementById("theNumber").innerHTML = input;
}

function increase() {
    var a = 1;
    var textBox = document.getElementById("NumberOfBurgers");
    textBox.innerHTML++;
}

function decrease() {
    var textBox = document.getElementById("NumberOfBurgers");
    if (textBox.innerHTML > 0) textBox.innerHTML--;
}

function updateCart() {
    let current_number = document.getElementById("theNumber").innerHTML;
    let input = document.getElementById("NumberOfBurgers").innerHTML;
    current_number = parseInt(current_number) + parseInt(input);
    document.getElementById("theNumber").innerHTML = current_number;
}

function unhideReview() {
    console.log("InUnhideReview");
    var x = document.querySelector(".reviewSection");
    if (x.style.display === "none") {
        x.style.display = "block";
        x.classList.add("reviewSectionAnimation");
    } else {
        x.style.display = "none";
    }
}

function submit() {
    var warningMessage = document.querySelector("#warningMessage");
    let letterCount = currentLength;
    if (letterCount == 0) {
        warningMessage.style.display = "block";
    }
    let name = document.getElementById("reviewerName");
    if (name == "" || name == null) {
        console.log("InCondition");
        name.value = "Customer";
    }
}

function cartView() {
    $('#cartModal').modal("show");
}

function cartHide() {
  $('#cartModal').modal("hide");
}
