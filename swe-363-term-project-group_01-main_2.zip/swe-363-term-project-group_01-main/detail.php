<?php require_once 'include/inc.header.php';

$meal = new Meal;
$meal = $meal->getMealById($_GET['id']-1);
$meal_facts = $meal["nutrition"]["facts"];
$meal_reviews = $meal["reviews"];

echo $meal["id"];
?>

<div class="container mt-6">
    <div class="row">
        <div class="col-lg-5 ">

            <img src=<?php echo $meal["image"]?> width="100%">
        </div>
        <div class="col-lg-7">
            <h1 class="TitlesL"><?php echo $meal["title"] ?></h1>
            <p>23.9</p>

            <p class="pageText">Lorem ipsum dolor sit amet consectetur adipisicing elit. Neque ullam deserunt laborum, laboriosam veritatis quibusdam blanditiis dolor exercitationem velit commodi quae assumenda incidunt voluptas. Corporis ex nulla repellendus ullam nihil!</p>

            <button onclick="decrease()" style="cursor: pointer" class="button button1">-</button>
            <button class="button button1"><span id="NumberOfBurgers">1</span></button>
            <button onclick="increase()" style="cursor: pointer" class="button button1">+</button>
            <button onclick="updateCart()" style="cursor: pointer" class="button button1">Add to Cart</button>
        </div>
    </div>
</div>

<div class="container mt-4">
    <div class="row">
        <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
            <li class="nav-item" role="presentation">
                <button class="nav-link colorandfont active" id="pills-home-tab" data-bs-toggle="pill" data-bs-target="#pills-description" type="button" role="tab" aria-controls="pills-description" aria-selected="true">Description</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link colorandfont" id="pills-profile-tab" data-bs-toggle="pill" data-bs-target="#pills-profile" type="button" role="tab" aria-controls="pills-profile" aria-selected="false">Reviews</button>
            </li>

        </ul>
        <div class="tab-content" id="pills-tabContent">
            <div class="tab-pane fade show active" id="pills-description" role="tabpanel" aria-labelledby="pills-home-tab">
                <p><?php echo $meal["description"] ?> </p>

                <div class="container">
                    <div class="row">
                        <h4>nutrition facts</h4>
                        <div id="nutritionTable ">

                            <table>
                                <tr class="oddRows ">
                                    <td colspan="3 "><b>Supplement Facts</b></td>
                                </tr>
                                <tr class="evenRows ">
                                    <td colspan="3 "><b>Serving Size:</b><?php echo $meal["nutrition"]["serving_size"] ?></td>
                                </tr>
                                <tr class="oddRows ">
                                    <td colspan="3 "><b>Serving Per Container:</b><?php echo $meal["nutrition"]["serving_per_container"] ?></td>
                                </tr>
                                <tr class="evenRows ">
                                    <td></td>
                                    <td><b>Amount Per Serving</b></td>
                                    <td><b>%Daily Value*</b></td>
                                </tr>
                                <?php

                                for($x=0; $x<count($meal_facts); $x++){
                                    echo'<tr class="oddRows ">';
                                    echo'<td>'.$meal_facts[$x]["item"].'</td> ';
                                    echo '<td>'.$meal_facts[$x]["amount_per_serving"];echo " ".$meal_facts[$x]["unit"].'</td>';
                                    echo'<td>'.$meal_facts[$x]["daily_value"].'</td> ';
                                    echo'</tr>';

                                    $y=++$x;
                                    if($y<count($meal_facts)) {
                                        echo '<tr class="evenRows ">';
                                        echo '<td>' . $meal_facts[$y]["item"] . '</td> ';
                                        echo '<td>' . $meal_facts[$y]["amount_per_serving"];
                                        echo " " . $meal_facts[$y]["unit"] . '</td>';
                                        echo '<td>' . $meal_facts[$y]["daily_value"] . '</td> ';
                                        echo '</tr>';
                                    }

                                }

                                ?>
                                <tr class="oddRows ">
                                    <td colspan="3 ">* Percent Daily Values are based on a 2,000 calorie diet. Your daily values may be higher or lower depending on your calorie needs</td>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <div class="tab-pane fade" id="pills-profile" role="tabpanel" aria-labelledby="pills-profile-tab">
                <div class="row">
                    <div class="col">
                        <img src=<?php echo $meal_reviews["image"]?> width="100%">
                    </div>
                    <div class="col">
                        <h4><?php echo $meal_reviews["reviewer_name"] ?></h4>
                        <h5><?php echo $meal_reviews["city"] ?> - <?php echo $meal_reviews["date"] ?> <?php for($x=0; $x<$meal_reviews["rating"]; $x++){echo "&#11088; ";} ?></h5>
                        <p><?php echo $meal_reviews["review"] ?></p>
                    </div>


                </div>

                <div class="row">
                    <div>
                        <div>
                            <p>
                                <form action="detail.html" method="get">

                                    <button type="button" class="btn btn-warning" onclick="unhideReview()">Add your Review</button>
                                    <div class="reviewSection">

                                        <br>
                                        <label for="Image">Image</label>
                                        <br>
                                        <input type="file" id="Image" name="Image" accept="image/png, image/jpeg ">


                                        <label for="ٍRating" id="rate"><br>Rate the food</label>
                                        <br> <input type="range" id="rate" name="rate" min="0" max="100" step="20" list="rateList">
                                        <datalist id="rateList">
                                            <option>20</option>
                                            <option>40</option>
                                            <option>60</option>
                                            <option>80</option>
                                            <option>100</option>
                                        </datalist>

                                        <label for="Name"><br>Name</label>
                                        <br>
                                        <input type="text" id="reviewerName" name="Name" value="Customer">
                            <p>Review</p>
                            <div id="warningMessage">Please type your review !</div>

                            <label class="textareaContainer ">
                                <textarea maxlength="500" rows="15" cols="35" id="reviewArea" placeholder="Type your review here max 500 characters"></textarea>
                                <div id="counter"></div>
                            </label>

                            <!-- <br><input type="submit" id="btn4" value="Submit"> -->
                            <button type="button" class="btn btn-warning" onclick="submit()">Submit</button>
                            </form>
                            </p>

                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>

</div>









<?php require_once 'include/inc.footer.php'?>