<?php


$cartItem = $_GET["id"];
$cartItems[] = json_decode($_GET["back"]);
$cartItems[] = $cartItem;
$cartItems[] = $cartItem;
$cartItems[] = $cartItem;

print_r($cartItems);


setcookie("cart", "" ,time()-3600*24,'/');
setcookie("cart", json_encode($cartItems) ,time()+3600*24,'/');


header("Location: ../index.php");
