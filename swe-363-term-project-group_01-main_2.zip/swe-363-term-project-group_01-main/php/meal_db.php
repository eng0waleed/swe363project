<?php


class Meal_db
{

    public PDO $pdo;

    public function __construct(){

        $this->pdo = new PDO("mysql:server=localhost;dbname=meal","root","");

    }

    function getAllMeals(){
        $query = "SELECT * FROM meal;";
        $statement = $this->pdo->prepare($query);
        $statement->execute();
        return $statement->fetchAll();
    }



}