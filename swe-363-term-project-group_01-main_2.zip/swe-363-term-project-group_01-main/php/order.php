<?php

setcookie("recent-bought", "" , time()-3600*24, '/');
setcookie("recent-Total", "", time()-3600*24,'/');

$tempVar = $_POST["mealsIDs"];
$tempTotal = $_POST["cartTotal"];

/*
print_r($tempVar);
echo $tempTotal;
*/


setcookie("cart","",time()-3600,'/');
setcookie("recent-bought", json_encode($tempVar) , time()+3600*24, '/');
setcookie("recent-Total", "$tempTotal", time()+3600*24,'/');

/*
$trytemp = json_decode($_COOKIE["recent-bought"]);

print_r($trytemp);
*/
header("Location: ../index.php");


